# RobsRUtils
Handy R utils I have come across or coded up myself
